export default [
  "ENTITY_NAME",
  "UA",
  "MEDIAN_AGE",
  "APP_LAUNCHES",
  "APP_LAUNCHES_P_PER",
  "APP_LAUNCHES_INDEX",
  "PAGE_VIEWS",
  "TIME_SPENT_BROWSER",
  "TIME_SPENT_STATIC",
  "POP_BASE",
  "AVG_AUD_SHR_STATIC",
  "frequency",
  "platform",
  "device"
];
