import gridColumnNames from "../content/gridColumnNames";
import labels from "../content/chartLabels";
let colorIndex = 0;
let borderColorIndex = 0;
let masterRowData = [];
let producedData = [];
function capitalize(name) {
  return name.charAt(0).toUpperCase() + name.slice(1);
}
export function generateColumnDef() {
  const columnDefs = gridColumnNames.map((name, index) => {
    // eslint-disable-next-line
    return index == 0
      ? Object.assign(
          {},
          {
            headerName: capitalize(name),
            field: name,
            checkboxSelection: true,
            filter: true,
            sortable: true,
            cellClass: function(params) {
              return params.rowIndex % 2 ? ["row-1"] : ["row-2"];
            }
          }
        )
      : Object.assign(
          {},
          {
            headerName: capitalize(name),
            field: name,
            filter: true,
            sortable: true,
            cellClass: function(params) {
              return params.rowIndex % 2 ? ["row-1"] : ["row-2"];
            }
          }
        );
  });
  return columnDefs;
}

function subset(object, properties) {
  let requiredObject = {};
  for (let property of properties) {
    requiredObject[property] = object[property];
  }
  return requiredObject;
}
export function generateRowData(Data) {
  let rowData = Data.map(data => subset(data, gridColumnNames));
  masterRowData = rowData;
  producedData = rowData;
  return rowData;
}
export function getUniqueRows() {
  const uniqueRows = [
    ...new Set(masterRowData.map(data => data["ENTITY_NAME"]))
  ];
  return uniqueRows;
}
function getBackgroundColor(type) {
  const colors = ["#C3E9E6", "#60D0E0", "#427397", "#6398EE"];
  const borderColors = ["#C3EFEC", "#7BD5EF", "#5FB1EE", "#51CFD3"];
  // eslint-disable-next-line
  return type != "border"
    ? colors[colorIndex++ % colors.length]
    : borderColors[borderColorIndex++ % borderColors.length];
}
export function generateChartData(chartData) {
  let chartLabels = {};
  for (let label of labels) {
    chartLabels[label] = [];
  }
  chartData.map(data => {
    let keys = Object.keys(data);
    for (let key of keys) {
      chartLabels[key].push(data[key]);
    }
    return 0;
  });
  const datasets = labels.map((label, index) => {
    // eslint-disable-next-line
    return index != 0
      ? Object.assign(
          {},
          {
            label: label,
            fill: false,
            borderColor: getBackgroundColor("border"),
            data: chartLabels[label],
            backgroundColor: getBackgroundColor()
          }
        )
      : "";
  });
  datasets.shift();
  const data = {
    labels: chartLabels[labels[0]],
    datasets
  };
  return data;
}
export function getUniqueItems(filterItem, auxiloryData = producedData) {
  const uniqueItems = [...new Set(auxiloryData.map(data => data[filterItem]))];
  return uniqueItems;
}
export function filterData(criteria, property, auxiloryData = producedData) {
  const filteredData = auxiloryData.filter(
    data => criteria.indexOf(data[property]) > -1
  );
  return filteredData;
}
