import React, { Component } from "react";
import { FormattedMessage } from "react-intl";
import "./footer.css";
class Footer extends Component {
  render() {
    return (
      <div className="footer-container">
        <footer>
          <strong>
            <FormattedMessage id="footer.message" defaultMessage="DashBoard" />
          </strong>{" "}
          by{" "}
          <a href="https://valuelabs.facebook.com/profile.php?id=100030664552742">
            Rohik Galli
          </a>
          .
        </footer>
      </div>
    );
  }
}

export default Footer;
