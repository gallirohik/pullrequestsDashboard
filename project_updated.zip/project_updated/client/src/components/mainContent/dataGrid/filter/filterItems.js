export default {
  frequency: {
    100: "daily",
    145: "weekly"
  },
  platform: {
    0: "TotalDigital",
    1: "computer",
    2: "mobile"
  },
  device: {
    0: "TD Device",
    1: "ipad",
    2: "cellphone",
    3: "laptop",
    4: "desktop"
  }
};
