import React from "react";
function Checkbox(props) {
  function handleChange(event, item) {
    const { name, checked } = event.target;
    if (checked) {
      props.checkedItems.push(item);
    } else {
      props.checkedItems.splice(props.checkedItems.indexOf(item), 1);
    }
    //console.log(props.checkedItems);
    props.setSelectedItems(props.checkedItems);
  }
  let checkboxItems = props.items.map((item, index) => (
    <span key={index} className="checkbox-item">
      <input
        key={item}
        name={item}
        type="checkBox"
        name={props.label[item]}
        onChange={event => handleChange(event, item)}
      />
      <label key={props.label[item]}>{props.label[item]}</label>
    </span>
  ));

  return <React.Fragment>{checkboxItems}</React.Fragment>;
}
export default Checkbox;
