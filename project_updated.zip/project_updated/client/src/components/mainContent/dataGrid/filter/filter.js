import React, { Component } from "react";
import BrandNames from "../brandNames/brandNames";
import filterItems from "./filterItems";
import Checkbox from "./checkBox";
import { getUniqueItems } from "../../../../utils/gridChartHelpers";
import { filterData } from "../../../../utils/gridChartHelpers";
class Filter extends Component {
  constructor(props) {
    super(props);
    this.setSelectedFrequecies = this.setSelectedFrequecies.bind(this);
    this.setSelectedPlatforms = this.setSelectedPlatforms.bind(this);
    this.setSelectedDevices = this.setSelectedDevices.bind(this);

    this.state = {
      selectedFrequencies: [],
      selectedPlatforms: [],
      selectedDevices: [],
      checkedItems: [],
      auxiloryFrequencyData: [],
      auxiloryPlatformData: [],
      auxiloryDeviceData: []
    };
  }

  setSelectedFrequecies(selectedFrequencies) {
    this.setState({
      selectedFrequencies,
      auxiloryFrequencyData: filterData(selectedFrequencies, "frequency")
    });
    this.props.setRowData(this.state.auxiloryDeviceData);
  }
  setSelectedPlatforms(selectedPlatforms) {
    this.setState(function(prevState) {
      return {
        selectedPlatforms,
        auxiloryPlatformData: filterData(
          selectedPlatforms,
          "platform",
          prevState.auxiloryFrequencyData
        )
      };
    });
    this.props.setRowData(this.state.auxiloryDeviceData);
  }
  setSelectedDevices(selectedDevices) {
    const auxiloryDeviceData = filterData(
      selectedDevices,
      "device",
      this.state.auxiloryPlatformData
    );
    this.setState({
      selectedDevices,
      auxiloryDeviceData
    });
    this.props.setRowData(auxiloryDeviceData);
  }
  componentDidMount() {}
  render() {
    return (
      <div className="filters">
        <div className="filter-item">
          <p>Frequency</p>
          <div className="checkbox-container">
            <Checkbox
              items={getUniqueItems("frequency")}
              label={filterItems["frequency"]}
              setSelectedItems={this.setSelectedFrequecies}
              checkedItems={this.state.selectedFrequencies}
            />
          </div>
        </div>
        <div className="filter-item">
          <p>Platform</p>
          <Checkbox
            items={getUniqueItems("platform", this.state.auxiloryFrequencyData)}
            label={filterItems["platform"]}
            setSelectedItems={this.setSelectedPlatforms}
            checkedItems={this.state.selectedPlatforms}
          />
        </div>
        <div className="filter-item">
          <p>Device</p>
          <Checkbox
            items={getUniqueItems("device", this.state.auxiloryPlatformData)}
            label={filterItems["device"]}
            setSelectedItems={this.setSelectedDevices}
            checkedItems={this.state.selectedDevices}
          />
        </div>
        <div className="filter-item">
          <button className="button " onClick={() => this.props.handleClick()}>
            {this.props.buttonMessage}
          </button>
          {this.props.show ? (
            <div className="column">
              <BrandNames
                names={this.props.names}
                filterRows={this.props.filterRows}
                handleShow={this.props.handleShow}
              />
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}

export default Filter;
