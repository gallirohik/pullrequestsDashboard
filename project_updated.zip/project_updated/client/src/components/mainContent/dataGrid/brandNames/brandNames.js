import React, { Component } from "react";
import "./brandNames.css";
class BrandNames extends Component {
  constructor() {
    super();
    this.names = "";
    this.brandName = "";
    this.startIndex = 0;
    this.endIndex = 2;
    this.offSet = 2;
    this.page = 1;
    this.state = {
      options: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.toggleClass = this.toggleClass.bind(this);
    this.handleSaveChanges = this.handleSaveChanges.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.getPage = this.getPage.bind(this);
  }
  componentDidMount() {
    const { names } = this.props;
    this.names = names;
    let options = this.names.slice(this.startIndex, this.endIndex).map(name => (
      <label key={name} className="modal-container">
        {name}
        <input
          type="radio"
          name="brandName"
          value={name}
          onChange={event => this.handleChange(event)}
        />
        <span className="checkmark" />
      </label>
    ));
    options.join("");
    this.setState({ options });
  }
  handleChange(event) {
    const { value } = event.target;
    this.brandName = value;
  }

  toggleClass() {
    const modal = document.getElementById("modal");
    modal.classList.toggle("is-active");
  }
  handleSaveChanges() {
    this.brandName === ""
      ? alert("You haven't selected any Brand name, please select any brand")
      : this.props.filterRows(this.brandName);
    this.toggleClass();
  }
  handleClose() {
    this.toggleClass();
    this.props.handleShow();
  }
  getPage(page) {
    if (page === "next") {
      document.getElementById("prev").disabled = false;
      this.startIndex = this.endIndex;
      this.endIndex += this.offSet;
      this.endIndex =
        this.endIndex > this.names.length ? this.names.length : this.endIndex;
      if (this.endIndex >= this.names.length) {
        document.getElementById("next").disabled = true;
      }
      this.page++;
    } else {
      document.getElementById("next").disabled = false;
      this.endIndex = this.startIndex;
      this.startIndex -= this.offSet;
      this.startIndex = this.startIndex < 0 ? 0 : this.startIndex;
      if (this.startIndex <= 0) {
        document.getElementById("prev").disabled = true;
      }
      this.page--;
    }
    const options = this.names
      .slice(this.startIndex, this.endIndex)
      .map(name => (
        <label key={name} className="modal-container">
          {name}
          <input
            type="radio"
            name="brandName"
            value={name}
            onChange={event => this.handleChange(event)}
          />
          <span className="checkmark" />
        </label>
      ));
    options.join("");
    this.setState({ options });
  }

  render() {
    return (
      <div id="modal" className="modal is-active">
        <div className="modal-background" />
        <div className="modal-card">
          <header className="modal-card-head">
            <p className="modal-card-title">Select Brand Name</p>
            <button
              onClick={() => this.handleClose()}
              className="delete"
              aria-label="close"
            />
          </header>
          <section className="modal-card-body">
            <div className="column is-centered">{this.state.options}</div>
          </section>

          <footer className="modal-card-foot">
            <button
              onClick={() => this.handleSaveChanges()}
              className="button is-success"
            >
              Apply
            </button>
            <button onClick={() => this.handleClose()} className="button">
              Cancel
            </button>
            <div className="level-right pagenation">
              <label>{`1 to ${this.endIndex % this.offSet || this.offSet} of ${
                this.offSet
              }`}</label>
              <button
                onClick={() => this.getPage("prev")}
                className="button is-small"
                id="prev"
              >
                {"< <"}
              </button>
              <label>{`page ${this.page} of   ${Math.ceil(
                this.names.length / this.offSet
              )}`}</label>
              <button
                onClick={() => this.getPage("next")}
                className="button is-small"
                id="next"
              >
                {"> >"}
              </button>
            </div>
          </footer>
        </div>
      </div>
    );
  }
}
export default BrandNames;

/** <div className="select is-info">
      <select
        name="brands"
        onChange={event => {
          props.filterRows(event.target.value);
        }}
      >
        {options}
      </select>
    </div>*/
