import React from "react";
function ExportToCSV(props) {
  function toggleClass() {
    const modal = document.getElementById("exportModal");
    modal.classList.toggle("is-active");
    props.closeExportModal();
  }
  function handleExport() {
    props.onBtExport("#fileName", "#columnSeparator");
    props.closeExportModal();
  }
  return (
    <div id="exportModal" className="modal is-active">
      <div className="modal-background" />
      <div className="modal-card">
        <header className="modal-card-head">
          <p className="modal-card-title">Export to CSV</p>
          <button
            className="delete"
            aria-label="close"
            onClick={() => toggleClass()}
          />
        </header>
        <section className="modal-card-body">
          <div className="column control columns">
            <div className="column">
              <input
                id="fileName"
                className="input"
                type="text"
                placeholder="File Name"
              />
            </div>
            <div className="column">
              <input
                id="columnSeparator"
                className="input"
                type="text"
                placeholder="separator"
              />
            </div>
          </div>
        </section>
        <footer className="modal-card-foot">
          <button className="button is-success" onClick={() => handleExport()}>
            Export
          </button>
          <button className="button" onClick={() => toggleClass()}>
            Cancel
          </button>
        </footer>
      </div>
    </div>
  );
}
export default ExportToCSV;
