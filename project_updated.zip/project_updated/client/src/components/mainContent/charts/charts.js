import React from "react";
import { Line, Bar, Pie, Doughnut } from "react-chartjs-2";
import { defineMessages, injectIntl } from "react-intl";
function Chart(props) {
  const data = {
    labels: props.data.labels,
    datasets: props.data.datasets
  };
  const chartTitle = defineMessages({
    chartTitle: {
      id: "chartTitle",
      defaultMessage: "Unique Audience"
    }
  });
  const { intl } = props;

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    title: {
      text: intl.formatMessage(chartTitle.chartTitle),
      display: true,
      fontSize: 25
    },
    legend: {
      display: true,
      position: "bottom",
      labels: {
        fontColor: "#60CEEB"
      }
    },
    layout: {
      padding: {
        left: 10,
        top: 0,
        right: 30,
        bottom: 0
      }
    },
    tooltips: {
      enabled: true
    }
  };

  function chartType() {
    switch (props.type) {
      case "bar":
        return <Bar data={data} options={options} />;
      case "pie":
        return <Pie data={data} options={options} />;
      case "doughnut":
        return <Doughnut data={data} options={options} />;
      default:
        return <Line data={data} options={options} />;
    }
  }
  return chartType();
}
export default injectIntl(Chart);
/*
{
        label: "Hello",
        data: chartData,
        backgroundColor: [],
        bordercolor: ""
      }*/
