import React from "react";
function sayLoading() {
  return (
    <div>
      <h2>Loading...</h2>
    </div>
  );
}
function Loader() {
  return window.setTimeout(sayLoading, 2000);
}
export default Loader;
