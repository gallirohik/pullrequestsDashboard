const express = require("express");
const content = require("./content");
const app = express();
app.get("/api/", (req, res) => {
  res.send(JSON.stringify(content));
});
const port = process.env.port || 3010;
app.listen(port, () => {
  console.log(`Listening to Port ${port}`);
});
