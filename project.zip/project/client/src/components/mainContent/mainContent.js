import React, { Component } from "react";
import DataGrid from "./dataGrid/dataGrid";
import Chart from "./charts/charts";
import { FormattedMessage } from "react-intl";
import "./dataGrid/dataGrid.css";
import "./mainContent.css";
import {
  generateColumnDef,
  generateRowData,
  generateChartData
} from "../../utils/gridChartHelpers";
class MainContent extends Component {
  constructor(props) {
    super(props);
    this.name = "";
    this.state = {
      columnDefs: [],
      rowData: [],
      chartData: [],
      ChartLabels: [],
      display: false,
      rowDataMaster: [],
      isLoading: true
    };
    this.filterRows = this.filterRows.bind(this);
  }
  componentDidMount() {
    const url = "/api/";
    fetch(url)
      .then(response => response.json())
      .then(data => {
        this.setState({
          columnDefs: generateColumnDef(),
          rowData: generateRowData(
            data.content.Grid.payload.dataServiceQueryResults.data
          ),
          rowDataMaster: generateRowData(
            data.content.Grid.payload.dataServiceQueryResults.data
          ),
          chartData: generateChartData(
            data.content.Chart.payload.dataServiceQueryResults.data
          )
        });
      })
      .catch(err => {
        console.log("Something went wrong...!", err);
      });
    this.setState({ isLoading: true });
  }
  filterRows(name, status) {
    if (!status) {
      const newRows = this.state.rowDataMaster.filter(
        row => row["ENTITY_NAME"] === name
      );
      this.setState({
        rowData: newRows
      });
    } else {
      const rowData = this.state.rowDataMaster;
      this.setState({
        rowData
      });
    }
  }

  render() {
    return (
      <React.Fragment>
        <DataGrid
          columnDefs={this.state.columnDefs}
          rowData={this.state.rowData}
          rowSelection={"single"}
          filterRows={this.filterRows}
        />
        <div className="charts-container">
          <div className="chart">
            <p className="grid-label">
              <FormattedMessage
                id="lineChartLabel"
                defaultMessage="Page Views"
              />
            </p>
            <div className="chart-canvas">
              <Chart data={this.state.chartData} type={"line"} />
            </div>
          </div>
          <div className="chart">
            <p className="grid-label">
              <FormattedMessage
                id="barChartLabel"
                defaultMessage="video Views"
              />
            </p>
            <div className="chart-canvas">
              <Chart data={this.state.chartData} type={"bar"} />
            </div>
          </div>
          <div className="chart">
            <p className="grid-label">
              <FormattedMessage
                id="doughnutChartLabel"
                defaultMessage="Time Spent"
              />
            </p>
            <div className="chart-canvas">
              <Chart data={this.state.chartData} type={"doughnut"} />
            </div>
          </div>
          <div className="chart">
            <p className="grid-label">
              <FormattedMessage
                id="pieChartLabel"
                defaultMessage="App Launches"
              />
            </p>
            <div className="chart-canvas">
              <Chart data={this.state.chartData} type={"pie"} />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
export default MainContent;
//<Chart data={generateChartData()} type={this.state.type} />
/*

 <React.Fragment>
        <div className="grid-container-parent">
          <DataGrid
            columnDefs={this.state.columnDefs}
            rowData={this.state.rowData}
            rowSelection={"single"}
          />
        </div>
        <div className="chart-container">
          <div className="chart-item">
            
          </div>
          <div className="chart-item">
            <Chart data={this.state.chartData} type={"bar"} />
          </div>
        </div>
        <div className="chart-container">
          <div className="chart-item">
            <Chart data={this.state.chartData} type={"pie"} />
          </div>
          <div className="chart-item">
            <Chart data={this.state.chartData} type={"doughnut"} />
          </div>
        </div>
      </React.Fragment>

*/
