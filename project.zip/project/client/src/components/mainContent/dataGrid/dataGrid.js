import React, { Component } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";
import "./dataGrid.css";
import { FormattedMessage } from "react-intl";
import { getUniqueRows } from "../../../utils/gridChartHelpers";
import ExportToCSV from "./exportCSV";
import downloadIcon from "../../../images/downloadIcon.png";
import Filter from "./filter/filter";
class DataGrid extends Component {
  constructor() {
    super();
    this.onGridReady = this.onGridReady.bind(this);
    this.show = false;
    this.state = {
      buttonMessage: "Filter By Brand",
      showExport: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.onBtExport = this.onBtExport.bind(this);
    this.showExportModal = this.showExportModal.bind(this);
    this.closeExportModal = this.closeExportModal.bind(this);
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    window.addEventListener("resize", function() {
      setTimeout(function() {
        //params.api.sizeColumnsToFit();
      });
    });
  }
  handleClick() {
    if (!this.show) {
      this.setState({
        buttonMessage: "Show Grid"
      });
    } else {
      this.setState({ buttonMessage: "Filter By Brand" });
      this.props.filterRows("", this.show);
    }
    this.show = !this.show;
  }
  handleShow() {
    this.show = true;
    this.handleClick();
  }
  onBtExport(fileName, columnSeparator) {
    var params = {
      allColumns: true,
      fileName: document.querySelector(fileName).value,
      columnSeparator: document.querySelector(columnSeparator).value
    };
    this.gridApi.exportDataAsCsv(params);
  }
  showExportModal() {
    this.setState({ showExport: true });
  }
  closeExportModal() {
    this.setState({ showExport: false });
  }
  render() {
    return (
      <React.Fragment>
        <div className="grid-container ">
          <Filter
            names={getUniqueRows()}
            filterRows={this.props.filterRows}
            handleShow={this.handleShow}
            handleClick={this.handleClick}
            buttonMessage={this.state.buttonMessage}
            show={this.show}
          />
          <div className="grid ag-theme-balham">
            <header className="grid-header">
              <div className="grid-heading">
                <p>
                  {" "}
                  <FormattedMessage id="gridHeading" defaultMessage="Ratings" />
                </p>
              </div>

              <div className="icon-container">
                <img
                  className="download-icon"
                  src={downloadIcon}
                  onClick={() => this.showExportModal()}
                  alt="export to csv"
                />
              </div>
            </header>
            {this.state.showExport ? (
              <ExportToCSV
                onBtExport={this.onBtExport}
                closeExportModal={this.closeExportModal}
              />
            ) : (
              ""
            )}
            <AgGridReact
              onGridReady={this.onGridReady}
              columnDefs={this.props.columnDefs}
              rowData={this.props.rowData}
              pagination={true}
              paginationPageSize={10}
            />
          </div>
          <div className="grid-label">
            <p>
              {" "}
              <FormattedMessage id="gridLabel" defaultMessage="Brand Grid" />
            </p>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
export default DataGrid;
/*
this.getSelectedRows = this.getSelectedRows.bind(this);
 rowSelection={this.props.rowSelection}
getSelectedRows(e) {
    const selectedNodes = this.gridApi.getSelectedNodes();
    // eslint-disable-next-line
    if (selectedNodes == 0) {
      alert("You haven't selected any Language,Please select one Language");
    } else {
      const selectedData = selectedNodes.map(node => node.data);
      const selectedNode = selectedData.pop();
      this.props.generateChart(selectedNode.name);
    }
  }


  <button
                className="button is-primary"
                onClick={() => this.showExportModal()}
              >
                Export to CSV
              </button>




<div className="columns">
            <div className="column">
              <p className="grid-heading">
                {" "}
                <FormattedMessage id="gridHeading" defaultMessage="Ratings" />
              </p>
            </div>

            <div className="column">
              <button
                className="button is-primary"
                onClick={() => this.handleClick()}
              >
                {this.state.buttonMessage}
              </button>
              <img
                className="download-icon grid-label"
                src={downloadIcon}
                onClick={() => this.showExportModal()}
                alt="export to csv"
              />
            </div>

            {this.show ? (
              <div className="column">
                <BrandNames
                  names={getUniqueRows()}
                  filterRows={this.props.filterRows}
                  handleShow={this.handleShow}
                />
              </div>
            ) : (
              ""
            )}

            {this.state.showExport ? (
              <ExportToCSV
                onBtExport={this.onBtExport}
                closeExportModal={this.closeExportModal}
              />
            ) : (
              ""
            )}
          </div>

















*/
