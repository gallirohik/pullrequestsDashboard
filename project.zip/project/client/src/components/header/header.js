import React, { Component } from "react";
import { FormattedMessage } from "react-intl";
import "./header.css";
class Header extends Component {
  render() {
    return (
      <div id="navbar" className="headerContainer">
        <header>
          <h1 className="is-size-2">
            <FormattedMessage
              id="header.title"
              defaultMessage="Content Writter"
            />
          </h1>
        </header>
      </div>
    );
  }
}

export default Header;
