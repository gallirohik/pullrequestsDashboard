import React, { Component } from "react";
import Loader from "../loader/loader";
const LoaderHOC = WrappedComponent => {
  return class LoaderHOC extends Component {
    constructor(props) {
      super(props);
    }
    render() {
      console.log(this.props.rowData);
      return this.props.rowData.length === 0 ? (
        <Loader />
      ) : (
        <WrappedComponent {...this.props} />
      );
    }
  };
};
export default LoaderHOC;
